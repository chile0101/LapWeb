XAMPP version : 7.2.11

Please set ID -> AutoIncreament