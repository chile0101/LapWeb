
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New User</title>
</head>
<body>
    <form method="post" action="../Controller/UserController.php">
        Name: <input type="text" name = "name"><br><br>
        Year: <input type="text" name="year"><br><br>   
        <input type="submit" name ="submit" value="create" >

    </form>
</body>
</html>