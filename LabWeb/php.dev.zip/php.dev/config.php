<?php

// Define DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "123456");
define("DB_NAME", "shareboard");

// Define URL
define("ROOT_PATH", "/php.dev/");
define("ROOT_URL", "http://localhost/php.dev/");